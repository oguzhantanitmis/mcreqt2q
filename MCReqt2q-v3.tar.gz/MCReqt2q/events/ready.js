const chalk = require('chalk');
const moment = require('moment');
const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');
var colors = require('colors');

var prefix = ayarlar.prefix;

module.exports = client => {

    
  console.log(`Bot active, attacks loaded!`.green);
  client.user.setStatus("dnd");
};
