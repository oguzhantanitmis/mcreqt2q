const Discord = require("discord.js");

exports.run = async (client, message, args) => {
    const adminuser = message.member.roles.cache.has("856251317651111967")
    var attack = require('child_process').exec
    if(adminuser) {
      attack(`killall -9 java`, (error, stdout, stderr) => {
          const embed = new Discord.MessageEmbed()
          .setColor('RED')
          .setTitle('**👑 MCReqt**')
          .setTimestamp()
          .setDescription("Attacks ended by a admin!")
          .setFooter("© MCReqt by HamzaX - why")
          message.channel.send(embed)
      });
    }
}



exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['forcestop'],
  permLevel: 0
}

exports.help = {
  name: 'stop',
  description: 'HamzaaaaaaX',
  usage: 'stop'
}