const Discord = require("discord.js");
const moment = require('moment');
const https = require('https');
const fs = require('fs');


exports.run = async (client, message, args) => {
  var b = message.member.roles.cache.has("856251317651111967") && message.channel.id == "856249531146305587" || message.channel.id == "854396412750069760" || message.channel.id == "855757407724109835";
  if(args.length != 1 && b) {
    var updater = require('child_process').exec
    updater(`java -jar ArsevUpdater_obf.jar socks4 proxy.txt`, (error, stdout, stderr) => {
        console.log("[*] Proxy installed from database!")
        const embed = new Discord.MessageEmbed()
        .setColor('GREEN')
        .setTitle('**👑 MCReqt**')
        .setTimestamp()
        .setDescription(`Proxy installed in the file **proxy.txt**`)
        .setFooter("© MCReqt by HamzaX - why")
        message.channel.send(embed)
    });
  }
}



exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['upd'],
  permLevel: 0
}

exports.help = {
  name: 'update',
  description: 'hamzax',
  usage: 'update'
}