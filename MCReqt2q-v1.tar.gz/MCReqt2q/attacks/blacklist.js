const Discord = require("discord.js");
const db = require('quick.db');

exports.run = async (client, message, args) => {
    const adminuser = message.member.roles.cache.has("773881009397694475")
    var attack = require('child_process').exec
    if(adminuser && args.length == 2) 
    {
      if(args[0].toLowerCase() == "add") {
          const host = args[1]
          const blacklist = host.split(".").join("-");
          db.add("servers-" + blacklist, 1);
          const embed = new Discord.MessageEmbed()
          .setTitle("**👑 MCReqt** Server has blacklisted!")
          .setColor("GREEN")
          .setTimestamp()
          .setDescription("**Server adress**: `" + host + "`")
          .setFooter("© MCReqt by HamzaX - why")
          message.channel.send(embed)
      }else if(args[0].toLowerCase() == "remove") {
        const host = args[1]
        const blacklist = host.split(".").join("-");
        db.delete("servers-" + blacklist);
        const embed = new Discord.MessageEmbed()
        .setTitle("**👑 MCReqt** Server removed from blacklist!")
        .setColor("RED")
        .setTimestamp()
        .setDescription("**Server adress**: `" + host + "`")
        .setFooter("© MCReqt by HamzaX - why")
        message.channel.send(embed)
      }
   }
}



exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['forcestop'],
  permLevel: 0
}

exports.help = {
  name: 'blacklist',
  description: 'HamzaX',
  usage: 'blacklist'
}